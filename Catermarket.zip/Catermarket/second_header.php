
<div class="single_secondary_header" style="background-image: url('<?php echo get_the_post_thumbnail_url(); ?>');">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1><?php the_title(); ?></h1>
            </div>
        </div>
    </div>
    <div class="thumb_overlay"></div>
</div>
