<?php
/**
 * Single Product Price
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/price.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woo.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

?>
<!--
<p class="<?php echo esc_attr( apply_filters( 'woocommerce_product_price_class', 'price' ) ); ?>"><?php echo $product->get_price_html(); ?></p>
-->

<div class="product_card on_single_product">

<?php $product = wc_get_product(); ?>

<div class="price_red">
		<?php echo $product->get_price_html(); ?><br>
</div>
<!--
<div class="incl_vat_price">
  <?php
        $price_excl_tax = wc_get_price_excluding_tax( $product );
        echo $price_excl_tax > 0 || ! empty( $price_excl_tax ) ? wc_price( $price_excl_tax*1.15 ) . __(' Incl. VAT') : '';
  ?>
</div>
-->
</div>
